# ACVCsys
## 由大众维护的计算机病毒流行预警系统
### 客户端现可下载 
> 下载后请一定按照指示去做,否则有安装不成功的风险!
> [下载(不包含Python)](./Client/acvc_install_nopy.exe) 
> [下载(包含Python)](./Client/acvc_install_py37.exe)
> [下载卸载器](./Client/Unistall.bat)


## [BREAKING ALERT](./breaking0.acvam)


>如果您有能力,请私信Alancui4080@outlook.com



> ## WannaRen:
  >  [20200408015A-WannaRen.acvam](./2020-WannaRen/20200408015A-WannaRen.acvam)  <br />
  >  [20200409005A-WannaRen.acvam](./2020-WannaRen/20200409005A-WannaRen.acvam)

> ## master:
  > [20200408015A-WannaRen.acvam](./master/20200408015A-WannaRen.acvam)  <br />
  > [20200409005A-WannaRen.acvam](./master/20200409005A-WannaRen.acvam)


